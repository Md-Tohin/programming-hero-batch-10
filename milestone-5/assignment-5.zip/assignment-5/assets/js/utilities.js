//  Get Text 
function getText(id){
    const text = document.getElementById(id).innerText;
    return text;
}

//  Set Text
function setText(id, text){
    document.getElementById(id).innerText = text;
}